from django.db import models

class Kadra(models.Model):
    imie = models.CharField(max_length=100)
    nazwisko = models.CharField(max_length=100)
    Stanowisko = models.CharField(max_length=100)

    def __str__(self):
        return f"{self.Stanowisko} - {self.imie} {self.nazwisko}"

class Uslugi(models.Model):
    Nazwa = models.CharField(max_length=100)
    Cena = models.IntegerField()
    Kadra_id = models.ForeignKey(Kadra, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.Nazwa} - {self.Kadra_id.imie} {self.Kadra_id.nazwisko}"
