from django.forms import modelform_factory
from django.shortcuts import render, get_object_or_404, redirect
from beautyapp.models import *

def index(request):
    uslugi = Uslugi.objects.all()
    return render(request,'beauty.html',{'uslugi':uslugi})

def detail(request):
    kadra = Kadra.objects.all()
    return render(request, 'kadra.html',{'kadra':kadra})
forma = modelform_factory(Kadra, exclude=[''])

def new(request):
    kadra = get_object_or_404(Kadra,pk=1)
    if request.method == 'POST':
        form = forma(request.POST)
        if form.is_valid():
            form.save()
            return redirect('kadra')
    else:
        form = forma()
    return render(request,'new.html',{'form':form})
